#include <iostream>
#include <vector>

#include "lexer.h"

using namespace std;
struct SE
{
    string variable_name;
    string scope_variable;
    int scopevalue;
};



LexicalAnalyzer my_lexer;
vector<struct SE> ST;
vector<string> Final_result_swarali;
string scope_determination(string name_of_var, string scope_determination);
void let_the_program_parsing_begin();
vector<string> variables_to_list();
void scope_variable();
void parsing_the_global_variable();
void variable_parsing_public_and_private(string running_S);
void parsing_the_assignment(string curr_scope);
void game_end(string jass);